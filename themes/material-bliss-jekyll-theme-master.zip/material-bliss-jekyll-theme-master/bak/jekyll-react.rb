require 'jekyll_react/json-generator.rb'
