#!/bin/bash
NODE_ENV=development node_modules/.bin/babel-node --presets 'react,es2015' react-dev/render_to_file.js
